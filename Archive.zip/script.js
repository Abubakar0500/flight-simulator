function fly() {
  alert("Taking off! ✈️");
}
